from django.contrib import admin
from screamium.models import Order

# Register your models here.
admin.site.register(Order)